import CompA from './CompA'
function App(){
  const name="Innomatics"
  return(
    <>
<CompA name={name}/>
</>
  )
}
export default App

