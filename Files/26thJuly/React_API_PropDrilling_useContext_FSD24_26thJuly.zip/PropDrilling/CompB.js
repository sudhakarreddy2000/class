import CompC from './CompC'
function CompB({name}){
    return(
          <>
<CompC name={name}/>
      </>
    )
    }
    export default CompB