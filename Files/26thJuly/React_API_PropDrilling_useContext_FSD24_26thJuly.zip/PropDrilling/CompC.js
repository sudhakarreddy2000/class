function CompC({name}){
    return(
          <>
    <h2>Component C</h2>
    <h2>Hello {name}</h2>
      </>
    )
    }
    export default CompC