import CompB from './CompB'
function CompA({name}){

    return(
          <>
   <CompB name={name}/>
      </>
    )
    }
    export default CompA