function CompC(){
    return(
          <>
    <h2>My name is React</h2>
      </>
    )
    }
    export default CompC