import CompA from './CompA'
function App(){
  return(
    <>
    <CompA/>
</>
  )
}
export default App

