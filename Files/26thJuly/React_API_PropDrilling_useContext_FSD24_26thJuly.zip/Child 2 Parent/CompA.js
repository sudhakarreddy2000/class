import CompB from './CompB'
function CompA(){

    return(
          <>
    <CompB/>
      </>
    )
    }
    export default CompA