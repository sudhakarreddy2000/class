function CompB(){
    return(
          <>
    CompB
      </>
    )
    }
    export default CompB