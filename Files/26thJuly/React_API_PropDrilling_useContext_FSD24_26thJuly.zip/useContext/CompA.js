
function CompA(){

    return(
          <>
    <h2>Hello</h2>
      </>
    )
    }
    export default CompA