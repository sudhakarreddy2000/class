import reactDom from 'react-dom'
import App from './App'
reactDom.render(
  <App/>,
  document.getElementById('root')
)