function Courses(){
    return(
        <>
       <div className="container">
            <div className="row">
                <div className="col-md-4 bg-success"><h2>Courses</h2></div>
                <div className="col-md-8 bg-danger">        
                <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis quasi laudantium tempora consequatur repellat similique excepturi laborum. Consectetur, ducimus omnis totam culpa impedit, ea cum provident ut alias nulla distinctio temporibus. Inventore, optio numquam accusantium tempore ad aliquam laborum eaque, voluptate officia dolor quibusdam! Molestias minima porro vitae quod, velit sed totam eos vel placeat repellat minus quas dolor? Provident earum et hic ratione dicta laborum voluptatem, minima perferendis ullam voluptatum non adipisci quod cum deleniti, maiores eos tempore aspernatur, magni facere delectus quisquam nisi. Voluptatem cum nisi tempore numquam rerum voluptates nobis recusandae sequi temporibus quas, iste placeat magni vel, ipsa illum praesentium enim quos tempora commodi quam ipsum. Consectetur tempora itaque qui id ab nobis at quas atque suscipit quasi voluptatibus pariatur, iure dolore optio necessitatibus eos fugit hic tenetur enim aliquid temporibus. Labore commodi saepe quibusdam, nam praesentium, quisquam molestias sint, beatae neque ea ratione excepturi blanditiis.
        </p></div>
            </div>
        </div>
        </>
    )
}
export default Courses