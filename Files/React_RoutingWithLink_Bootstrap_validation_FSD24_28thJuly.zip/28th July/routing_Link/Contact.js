function Contact(){
    return(
        <>
        <h2>Contact us</h2>
        <form>
            <input type="text" placeholder="First Name "/>
            <br/>
            <input type="text" placeholder="Last Name "/>
            <br/>
            <input type="email" placeholder="Email "/>
            <br/>
            <input type="submit"/>
            <input type="reset"/>
            <br/>
        </form>
        </>
    )
}
export default Contact